
import sys
import os
import numpy  as np
import subprocess

from pyjdg import *

#--------------------------------------------------------------
def importResult(dlg):

  name_op2 = dlg.get_item_text('OP2File') 

  JPT.Exec(
     f"CmdImportTSVOp2Post({name_op2}, 1, 1.0472, 1.0472, 0, 0, 0)"
  )

  '''
  available_result_option = \
    JPT.GetAvailableResultOption(JPT.PostAnalysisType.POST_ANALYSIS_LINEAR_STATIC,
                                 1,
                                 1,
                                 "Displacement",
                                 "X",
                                 JPT.PostResultDataLoc.POST_LOC_ON_NODE,
                                 JPT.GetDefaultResultOption(JPT.PostAnalysisType.POST_ANALYSIS_LINEAR_STATIC,
                                                            1,
                                                            1,
                                                            "Displacement",
                                                            "X",
                                                            JPT.PostResultDataLoc.POST_LOC_ON_NODE))
  '''
  #CmdImportTSVOp2Post("C:/home/Job_2.op2", 1, 1.0472, 1.0472, 0, 0, 0)


def importOP2(dlg):
  print('-- importing result ----')
  importResult(dlg)



#--------------------------------------------------------------
def main():
    #dlg=JDGCreator(include_apply=False)
    dlg=JDGCreator(title="Dialog",resizable=True,validation=True, include_apply=False, include_ok=False)

    dlg.add_layout(name="レイアウト6",orientation=orientation.horizontal,layout="Window")
    dlg.add_label(name="ラベル6",width=100,height=30,text="OP2 file(*.op2)",layout="レイアウト6")
    dlg.add_browser(name="OP2File",mode="file",
        file_filter="OP2 file(*.op2), All Files(*.*)",layout="レイアウト6")

    dlg.add_layout(name="レイアウト7",orientation=orientation.horizontal,layout="Window")
    dlg.add_button(name="ボタン62",text="Import OP2",width=120,height=22,layout="レイアウト7")


    dlg.on_command("ボタン62",importOP2)

    dlg.generate_window()

#--------------------------------------------------------------
if __name__=='__main__':
    main()